import React from 'react'
import Auth from './Auth'

export default function LandingPage(props) {
  return (
    <div>
      <h3>From Landing Page</h3>
    </div>
  )
}
