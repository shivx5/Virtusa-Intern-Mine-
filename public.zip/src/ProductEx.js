const EXPRODUCTS=[
        {
            id:1,
            name:"Food",
            price:" ₹ 300",
            image:"https://tse4.mm.bing.net/th?id=OIP.WSjF8qsK-PzNVYLEvFO8CgHaE8&pid=Api&P=0",
            details:" amman institute of technology "
        },
        {
            id:2,
            name:"Slipper",
            price:" ₹ 200",
            image:"https://tse3.mm.bing.net/th?id=OIP.yZoViZhqqPOCWHzWxKQSmAHaIZ&pid=Api&P=0",
            details:"from srm institute of technology"
        },
        {
            id:3,
            name:"Caps",
            price:" ₹ 100",
            image:"https://tse2.mm.bing.net/th?id=OIP.hSgcAgLL5hN1TRczP7phtwHaFt&pid=Api&P=0",
            details:"from unknown of technology"
        },
        {
            id:4,
            name:"Design wall",
            price:" ₹ 6,000",
            image:"https://tse2.mm.bing.net/th?id=OIP.qLEhStkE42FpGO0n5BXCMQHaHa&pid=Api&P=0",
            details:"from Paavai institute of technology"
        },
        {
            id:5,
            name:"Laptop",
            price:" ₹ 50,000",
             image:"https://tse4.mm.bing.net/th?id=OIP.5EZRHGR0LgL2IWcQ511TkQHaF5&pid=Api&P=0",
            details:" amman institute of technology "
        },
        {
            id:6,
            name:"Camera",
            price:" ₹ 30,800",
            image:"https://tse4.mm.bing.net/th?id=OIP.1Lz_1ruji6x5diFtQi9kBwHaGe&pid=Api&P=0",
            details:"from srm institute of technology"
        },
        {
            id:7,
            name:"Save your Hair",
            price:"₹ 1200 only !",
            image:"https://tse4.mm.bing.net/th?id=OIP.Ivr3QcFgNS3IYVscVSjpSAHaNJ&pid=Api&P=0",
            details:"from unknown of technology"
        },
        {
            id:8,
            name:"Drums",
            price:" ₹ 1200 only!",
            image:"https://tse4.mm.bing.net/th?id=OIP.y09vmbejpa4XFbHm2-DDuAHaEf&pid=Api&P=0",
            details:"from Paavai institute of technology"
        },
        {
            id:9,
            name:"Chair",
            price:" ₹ 600",
             image:"https://tse4.mm.bing.net/th?id=OIP.XgPK9s3MLOrlLmkEofy3NgHaFj&pid=Api&P=0",
            details:" amman institute of technology "
        },
        {
            id:10,
            name:"Pant",
            price:" ₹ 200",
            image:"https://tse2.mm.bing.net/th?id=OIP.qUuolFfwuCXVn8VrNlPTJAHaIq&pid=Api&P=0",
            details:"from srm institute of technology"
        },
        {
            id:11,
            name:"Shirt",
            price:"₹ 200",
            image:"https://tse4.mm.bing.net/th?id=OIP.tssKWxrvVV4x1XyZhcIfLQHaKh&pid=Api&P=0",
            details:"from unknown of technology"
        },
        {
            id:12,
            name:"Bag",
            price:" ₹ 800",
            image:"https://tse3.mm.bing.net/th?id=OIP.R53GGChC3DWOqkB2jQl2gAHaHa&pid=Api&P=0",
            details:"from Paavai institute of technology"
        }
        
    ]
    export default EXPRODUCTS;