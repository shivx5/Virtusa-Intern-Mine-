import React from 'react'

export default function AppLayout() {
  return (
    <div>
      <h3>App Layout</h3>
    </div>
  )
}
